<?php

interface ArtworkInterface{
    public function getTitle(): string;
    public function getDisplayHtml(): string;
}